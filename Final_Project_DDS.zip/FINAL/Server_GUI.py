import os

# Must be set before importing RTI Connector
os.environ["NDDS_DISCOVERY_PEERS"] = "udpv4://10.83.251.63,udpv4://10.83.250.137,udpv4://10.83.251.16,udpv4://10.83.250.201,udpv4://10.83.251.89,udpv4://10.83.250.54"

import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import rticonnextdds_connector as rti


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

CONFIG_NAME = "MyParticipantLibrary::Participant"
WRITER_NAME = "MyPub::MyWriter"
READER_NAME = "MySub::MyReader"
TOPIC_NAME = "EmergencyTopic"


def create_connector():
    """
    Same DDS loading behavior as the original working console scripts.
    RTI auto-loads USER_QOS_PROFILES.xml from the current directory.
    """
    return rti.Connector(CONFIG_NAME, url=None), "auto USER_QOS_PROFILES.xml"


def safe_percent(part, total):
    if total <= 0:
        return 0.0
    return (part / total) * 100.0


class ServerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("R-RDSP Server GUI")
        self.root.geometry("430x760")
        self.root.minsize(390, 620)

        # DDS state
        self.connector = None
        self.connector_source = "Not connected"
        self.reader = None
        self.writer = None
        self.running = False
        self.worker = None

        # Original server duplicate protection
        self.history = set()

        # Stats
        self.received = 0
        self.text_messages = 0
        self.multimedia_messages = 0
        self.replies_sent = 0
        self.help_replies = 0
        self.ok_replies = 0
        self.ignored = 0
        self.duplicates = 0
        self.saved_files = 0

        self.total_processing_ms = 0.0
        self.last_processing_ms = None
        self.started_at = None
        self.total_ttl = 0
        self.total_path_hops = 0
        self.last_saved_file = "None"

        # DDS/network palette
        self.bg = "#0D1B2A"
        self.panel = "#1B263B"
        self.card = "#25364D"
        self.accent = "#415A77"
        self.online = "#00B4D8"
        self.alert = "#EF476F"
        self.warning = "#FFD166"
        self.text = "#E0E1DD"
        self.muted = "#A9B4C2"
        self.black = "#08111F"
        self.good = "#66E6A6"

        self.setup_styles()
        self.build_ui()
        self.update_server_target()
        self.refresh_stats()
        self.start_ui_clock()

        self.log(f"[READY] NDDS_DISCOVERY_PEERS={os.environ['NDDS_DISCOVERY_PEERS']}")
        self.log("[READY] Server is not connected yet. Press Start Server.")

    # =========================
    # STYLE
    # =========================
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("TFrame", background=self.bg)
        style.configure("Panel.TFrame", background=self.panel)
        style.configure("Card.TFrame", background=self.card)

        style.configure("TLabel", background=self.bg, foreground=self.text, font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background=self.panel, foreground=self.text, font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=self.bg, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("PanelMuted.TLabel", background=self.panel, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=self.bg, foreground=self.text, font=("Segoe UI", 20, "bold"))
        style.configure("Subtitle.TLabel", background=self.bg, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("PanelHeader.TLabel", background=self.panel, foreground=self.text, font=("Segoe UI", 12, "bold"))
        style.configure("StatValue.TLabel", background=self.card, foreground=self.text, font=("Segoe UI", 14, "bold"))
        style.configure("StatLabel.TLabel", background=self.card, foreground=self.muted, font=("Segoe UI", 8))
        style.configure("Good.TLabel", background=self.panel, foreground=self.good, font=("Segoe UI", 10, "bold"))
        style.configure("Bad.TLabel", background=self.panel, foreground=self.alert, font=("Segoe UI", 10, "bold"))
        style.configure("Warn.TLabel", background=self.panel, foreground=self.warning, font=("Segoe UI", 10, "bold"))

        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=(8, 8))
        style.configure("Start.TButton", background=self.online, foreground=self.black)
        style.map("Start.TButton", background=[("active", "#27C7E6")])
        style.configure("Stop.TButton", background=self.alert, foreground="white")
        style.map("Stop.TButton", background=[("active", "#D93E63")])
        style.configure("Secondary.TButton", background=self.accent, foreground=self.text)
        style.map("Secondary.TButton", background=[("active", "#526C8B")])

        style.configure(
            "TSpinbox",
            fieldbackground=self.black,
            background=self.card,
            foreground=self.text,
            arrowcolor=self.text,
            bordercolor=self.accent,
            lightcolor=self.accent,
            darkcolor=self.accent,
        )

    # =========================
    # UI
    # =========================
    def build_ui(self):
        self.root.configure(bg=self.bg)

        self.main = ttk.Frame(self.root, padding=14)
        self.main.pack(fill="both", expand=True)
        self.main.columnconfigure(0, weight=1)
        self.main.rowconfigure(2, weight=1)

        ttk.Label(self.main, text="R-RDSP Server Node", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            self.main,
            text="Final destination server monitor for received messages, multimedia files, ACK replies, and response timing.",
            style="Subtitle.TLabel",
            wraplength=380,
        ).grid(row=1, column=0, sticky="ew", pady=(4, 10))

        self.content = ttk.Frame(self.main)
        self.content.grid(row=2, column=0, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=0)
        self.content.rowconfigure(1, weight=0)
        self.content.rowconfigure(2, weight=1)

        self.settings_frame = ttk.Frame(self.content, style="Panel.TFrame", padding=12)
        self.settings_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        self.stats_frame = ttk.Frame(self.content)
        self.stats_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))

        self.activity_frame = ttk.Frame(self.content, style="Panel.TFrame", padding=12)
        self.activity_frame.grid(row=2, column=0, sticky="nsew")
        self.activity_frame.columnconfigure(0, weight=1)
        self.activity_frame.rowconfigure(1, weight=1)

        self.build_settings()
        self.build_stats()
        self.build_activity()

        self.root.bind("<Configure>", self.on_resize)

    def build_settings(self):
        self.settings_frame.columnconfigure(0, weight=1)
        self.settings_frame.columnconfigure(1, weight=1)

        ttk.Label(self.settings_frame, text="Server Settings", style="PanelHeader.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )

        ttk.Label(self.settings_frame, text="Total Relays", style="PanelMuted.TLabel").grid(row=1, column=0, sticky="w")
        ttk.Label(self.settings_frame, text="Listen For Final", style="PanelMuted.TLabel").grid(row=1, column=1, sticky="w", padx=(10, 0))

        self.total_relays_var = tk.IntVar(value=1)

        self.relay_spin = ttk.Spinbox(
            self.settings_frame,
            from_=1,
            to=99,
            textvariable=self.total_relays_var,
            command=self.update_server_target,
            width=8,
        )
        self.relay_spin.grid(row=2, column=0, sticky="ew", pady=(4, 10))

        self.listen_final_label = ttk.Label(self.settings_frame, text="RELAY_01", style="PanelHeader.TLabel")
        self.listen_final_label.grid(row=2, column=1, sticky="w", padx=(10, 0), pady=(4, 10))

        ttk.Label(self.settings_frame, text="Reply Rule", style="PanelMuted.TLabel").grid(row=3, column=0, sticky="w")
        ttk.Label(self.settings_frame, text="HIGH -> HELP IS ON THE WAY", style="PanelHeader.TLabel").grid(
            row=4, column=0, columnspan=2, sticky="w", pady=(2, 8)
        )
        ttk.Label(self.settings_frame, text="LOW -> OK", style="PanelMuted.TLabel").grid(
            row=5, column=0, columnspan=2, sticky="w", pady=(0, 8)
        )

        self.status_label = ttk.Label(self.settings_frame, text="Disconnected", style="Bad.TLabel")
        self.status_label.grid(row=6, column=0, sticky="w", pady=(2, 8))

        self.connection_label = ttk.Label(self.settings_frame, text="DDS: Not connected", style="PanelMuted.TLabel")
        self.connection_label.grid(row=6, column=1, sticky="e", pady=(2, 8))

        self.toggle_btn = ttk.Button(
            self.settings_frame,
            text="Start Server",
            style="Start.TButton",
            command=self.toggle_server,
        )
        self.toggle_btn.grid(row=7, column=0, columnspan=2, sticky="ew", pady=(0, 8))

        tools_row = ttk.Frame(self.settings_frame, style="Panel.TFrame")
        tools_row.grid(row=8, column=0, columnspan=2, sticky="ew")
        tools_row.columnconfigure(0, weight=1)
        tools_row.columnconfigure(1, weight=1)

        ttk.Button(tools_row, text="Apply Target", style="Secondary.TButton", command=self.update_server_target).grid(
            row=0, column=0, sticky="ew", padx=(0, 4)
        )
        ttk.Button(tools_row, text="Clear Log", style="Secondary.TButton", command=self.clear_log).grid(
            row=0, column=1, sticky="ew", padx=(4, 0)
        )

    def build_stats(self):
        self.stats_container = self.stats_frame
        self.stats_widgets = []

        stat_specs = [
            ("Received", "0"),
            ("Replies", "0"),
            ("Ignored", "0"),
            ("Duplicates", "0"),
            ("Text", "0"),
            ("Multimedia", "0"),
            ("Files Saved", "0"),
            ("HELP ACK", "0"),
            ("OK ACK", "0"),
            ("Avg Time", "0.00 ms"),
            ("Last Time", "0.00 ms"),
            ("Msg Rate", "0.00/s"),
            ("Avg TTL", "0.0"),
            ("Avg Hops", "0.0"),
            ("Success %", "0.0%"),
            ("Last File", "None"),
        ]

        for label, value in stat_specs:
            self.stats_widgets.append(self.create_stat_card(self.stats_container, label, value))

        (
            self.received_value,
            self.replies_value,
            self.ignored_value,
            self.duplicates_value,
            self.text_value,
            self.multimedia_value,
            self.files_saved_value,
            self.help_ack_value,
            self.ok_ack_value,
            self.avg_time_value,
            self.last_time_value,
            self.msg_rate_value,
            self.avg_ttl_value,
            self.avg_hops_value,
            self.success_value,
            self.last_file_value,
        ) = [item[1] for item in self.stats_widgets]

        self.layout_stats_cards()

    def create_stat_card(self, parent, label, value):
        frame = ttk.Frame(parent, style="Card.TFrame", padding=(10, 8))
        title = ttk.Label(frame, text=label, style="StatLabel.TLabel")
        val = ttk.Label(frame, text=value, style="StatValue.TLabel")
        title.pack(anchor="w")
        val.pack(anchor="w")
        return frame, val

    def layout_stats_cards(self):
        width = max(self.root.winfo_width(), 390)

        if width < 620:
            cols = 2
        elif width < 980:
            cols = 3
        else:
            cols = 4

        for child in self.stats_container.winfo_children():
            child.grid_forget()

        for c in range(cols):
            self.stats_container.columnconfigure(c, weight=1)

        for index, (frame, _) in enumerate(self.stats_widgets):
            row = index // cols
            col = index % cols
            frame.grid(row=row, column=col, sticky="ew", padx=4, pady=4)

    def build_activity(self):
        ttk.Label(self.activity_frame, text="Activity Log", style="PanelHeader.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 8)
        )

        log_holder = ttk.Frame(self.activity_frame, style="Panel.TFrame")
        log_holder.grid(row=1, column=0, sticky="nsew")
        log_holder.columnconfigure(0, weight=1)
        log_holder.rowconfigure(0, weight=1)

        self.log_box = tk.Text(
            log_holder,
            bg=self.black,
            fg=self.text,
            insertbackground=self.text,
            relief="flat",
            font=("Consolas", 9),
            wrap="word",
            height=8,
        )
        self.log_box.grid(row=0, column=0, sticky="nsew")

        self.log_scroll = ttk.Scrollbar(log_holder, orient="vertical", command=self.log_box.yview)
        self.log_scroll.grid(row=0, column=1, sticky="ns")
        self.log_box.configure(yscrollcommand=self.log_scroll.set)

        self.log_box.bind("<MouseWheel>", self.scroll_log)
        self.log_box.bind("<Button-4>", self.scroll_log)
        self.log_box.bind("<Button-5>", self.scroll_log)

        ttk.Label(self.activity_frame, text="Last Message", style="PanelHeader.TLabel").grid(
            row=2, column=0, sticky="w", pady=(10, 4)
        )

        self.last_message_label = ttk.Label(
            self.activity_frame,
            text="No message received yet",
            style="PanelMuted.TLabel",
            justify="left",
            wraplength=370,
        )
        self.last_message_label.grid(row=3, column=0, sticky="ew")

    def scroll_log(self, event):
        if getattr(event, "num", None) == 4:
            self.log_box.yview_scroll(-1, "units")
        elif getattr(event, "num", None) == 5:
            self.log_box.yview_scroll(1, "units")
        else:
            direction = -1 if event.delta > 0 else 1
            self.log_box.yview_scroll(direction, "units")
        return "break"

    def on_resize(self, event=None):
        width = self.root.winfo_width()

        if width >= 900:
            self.content.columnconfigure(0, weight=1)
            self.content.columnconfigure(1, weight=2)

            self.settings_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))
            self.stats_frame.grid(row=0, column=1, sticky="nsew", pady=(0, 10))
            self.activity_frame.grid(row=1, column=0, columnspan=2, sticky="nsew")
            self.last_message_label.configure(wraplength=max(360, width - 80))
        else:
            self.content.columnconfigure(0, weight=1)
            self.content.columnconfigure(1, weight=0)

            self.settings_frame.grid(row=0, column=0, sticky="ew", padx=0, pady=(0, 10))
            self.stats_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))
            self.activity_frame.grid(row=2, column=0, sticky="nsew")
            self.last_message_label.configure(wraplength=max(330, width - 50))

        self.layout_stats_cards()

    # =========================
    # SERVER TARGET
    # =========================
    def listen_for_final(self):
        return f"RELAY_{int(self.total_relays_var.get()):02d}"

    def update_server_target(self):
        self.listen_final_label.configure(text=self.listen_for_final())

        if self.running:
            self.log(f"[INFO] Server target changed. Listening for final node: {self.listen_for_final()}")

    # =========================
    # LOGGING
    # =========================
    def log(self, text):
        self.log_box.insert("end", f"{time.strftime('%H:%M:%S')}  {text}\n")
        self.log_box.see("end")

    def clear_log(self):
        self.log_box.delete("1.0", "end")

    def set_last_message(self, text):
        self.last_message_label.configure(text=text)

    # =========================
    # STATS
    # =========================
    def average_processing_ms(self):
        if self.received <= 0:
            return 0.0
        return self.total_processing_ms / self.received

    def message_rate(self):
        if not self.started_at:
            return 0.0
        elapsed = time.perf_counter() - self.started_at
        if elapsed <= 0:
            return 0.0
        return self.received / elapsed

    def average_ttl(self):
        if self.received <= 0:
            return 0.0
        return self.total_ttl / self.received

    def average_hops(self):
        if self.received <= 0:
            return 0.0
        return self.total_path_hops / self.received

    def refresh_stats(self):
        self.received_value.configure(text=str(self.received))
        self.replies_value.configure(text=str(self.replies_sent))
        self.ignored_value.configure(text=str(self.ignored))
        self.duplicates_value.configure(text=str(self.duplicates))
        self.text_value.configure(text=str(self.text_messages))
        self.multimedia_value.configure(text=str(self.multimedia_messages))
        self.files_saved_value.configure(text=str(self.saved_files))
        self.help_ack_value.configure(text=str(self.help_replies))
        self.ok_ack_value.configure(text=str(self.ok_replies))
        self.avg_time_value.configure(text=f"{self.average_processing_ms():.2f} ms")
        self.last_time_value.configure(text="0.00 ms" if self.last_processing_ms is None else f"{self.last_processing_ms:.2f} ms")
        self.msg_rate_value.configure(text=f"{self.message_rate():.2f}/s")
        self.avg_ttl_value.configure(text=f"{self.average_ttl():.1f}")
        self.avg_hops_value.configure(text=f"{self.average_hops():.1f}")
        self.success_value.configure(text=f"{safe_percent(self.replies_sent, self.received):.1f}%")

        if len(self.last_saved_file) > 18:
            display_name = "..." + self.last_saved_file[-15:]
        else:
            display_name = self.last_saved_file
        self.last_file_value.configure(text=display_name)

    def record_processing_time(self, elapsed_ms):
        self.last_processing_ms = elapsed_ms
        self.total_processing_ms += elapsed_ms

    def start_ui_clock(self):
        self.refresh_stats()
        self.root.after(1000, self.start_ui_clock)

    # =========================
    # START / STOP
    # =========================
    def toggle_server(self):
        if self.running:
            self.stop_server()
        else:
            self.start_server()

    def update_toggle_button(self):
        if self.running:
            self.toggle_btn.configure(text="Stop Server", style="Stop.TButton")
        else:
            self.toggle_btn.configure(text="Start Server", style="Start.TButton")

    def start_server(self):
        if self.running:
            return

        self.update_server_target()

        try:
            self.connector, self.connector_source = create_connector()
            self.reader = self.connector.get_input(READER_NAME)
            self.writer = self.connector.get_output(WRITER_NAME)
        except Exception as exc:
            self.status_label.configure(text="Connection failed", style="Bad.TLabel")
            self.connection_label.configure(text="DDS: Failed")
            self.log(f"[ERROR] DDS connection failed: {exc}")
            messagebox.showerror("DDS Connection Error", str(exc))
            return

        self.running = True
        self.started_at = time.perf_counter()
        self.history.clear()
        self.update_toggle_button()

        self.status_label.configure(text="Connected", style="Good.TLabel")
        self.connection_label.configure(text="DDS: Connected")
        self.log(f"[CONNECTED] DDS connected using {self.connector_source}")
        self.log(f"[START] Server waiting for final path node: {self.listen_for_final()}")

        self.worker = threading.Thread(target=self.server_loop, daemon=True)
        self.worker.start()

    def stop_server(self):
        self.running = False
        self.update_toggle_button()

        try:
            if self.connector is not None:
                self.connector.close()
        except Exception:
            pass

        self.connector = None
        self.reader = None
        self.writer = None

        self.status_label.configure(text="Disconnected", style="Bad.TLabel")
        self.connection_label.configure(text="DDS: Not connected")
        self.log("[DISCONNECTED] Server stopped")

    # =========================
    # ORIGINAL SERVER LOOP LOGIC
    # =========================
    def server_loop(self):
        while self.running:
            try:
                self.connector.wait(500)
            except rti.TimeoutError:
                continue
            except Exception as exc:
                if self.running:
                    self.root.after(0, lambda e=exc: self.log(f"[ERROR] Wait failed: {e}"))
                continue

            try:
                self.reader.take()
                for sample in self.reader.samples.valid_data_iter:
                    self.process_sample(sample)
            except Exception as exc:
                self.root.after(0, lambda e=exc: self.log(f"[ERROR] Sample handling failed: {e}"))

    def process_sample(self, sample):
        start = time.perf_counter()

        msg = sample.get_string("msg")
        if msg.startswith("HEARTBEAT|"):
            return
        ts = sample.get_string("timestamp")
        path = sample.get_string("mac_list") or ""
        path_nodes = [node.strip() for node in path.split(",") if node.strip()]
        self.log(f"[RX] msg={msg} path={path}")
        listen_for_final = self.listen_for_final()

        # Same server filtering logic as your original server.
        if not path_nodes:
            self.count_ignored(f"No path | msg='{msg}'")
            return

        if "REPLY:" in msg:
            self.count_ignored(f"Ignoring reply packet | msg='{msg}'")
            return

        if ts in self.history:
            self.duplicates += 1
            self.count_ignored(f"Duplicate timestamp {ts}")
            return

        if path_nodes[-1] != listen_for_final:
            self.count_ignored(f"Not final relay yet | expected={listen_for_final} got={path_nodes[-1]} | msg='{msg}'")
            return

        self.history.add(ts)

        ttl = int(sample.get_number("ttl"))
        prio = int(sample.get_number("priority"))
        prio_str = "HIGH / Emergency" if prio == 1 else "LOW / Normal"

        self.received += 1
        self.total_ttl += ttl
        self.total_path_hops += len(path_nodes)

        is_multi = sample.get_boolean("is_multimedia")

        saved_name = "None"
        if is_multi:
            self.multimedia_messages += 1
            raw_payload = sample.get_dictionary().get("payload", [])
            orig_filename = sample.get_string("filename") or "attachment.bin"
            safe_filename = os.path.basename(orig_filename)
            saved_name = f"received_{int(time.time())}_{safe_filename}"

            with open(saved_name, "wb") as f:
                f.write(bytes(raw_payload))

            self.saved_files += 1
            self.last_saved_file = saved_name
            content_note = f"Multimedia saved as {saved_name} ({len(raw_payload)} bytes)"
        else:
            self.text_messages += 1
            content_note = f"Text content: {msg}"

        # Same reply logic as original server.
        reply_text = "REPLY: HELP IS ON THE WAY" if prio == 1 else "REPLY: OK"

        self.writer.instance.set_string("msg", reply_text)
        self.writer.instance.set_string("mac_list", "SERVER")
        self.writer.instance.set_number("ttl", 5)
        self.writer.instance.set_string("timestamp", ts + "_ack")
        self.writer.write()

        self.replies_sent += 1
        if prio == 1:
            self.help_replies += 1
        else:
            self.ok_replies += 1

        elapsed_ms = (time.perf_counter() - start) * 1000.0
        self.record_processing_time(elapsed_ms)

        self.root.after(0, self.refresh_stats)
        self.root.after(
            0,
            lambda: self.log(
                f"[RECEIVED] path={' -> '.join(path_nodes)} | TTL={ttl} | priority={prio_str} | time={elapsed_ms:.2f}ms"
            ),
        )
        self.root.after(0, lambda: self.log(f"[CONTENT] {content_note}"))
        self.root.after(0, lambda: self.log(f"[REPLY] Sent '{reply_text}' to {path_nodes[0]}"))
        self.root.after(
            0,
            lambda: self.set_last_message(
                f"RECEIVED\n"
                f"Message: {msg}\n"
                f"Path: {' -> '.join(path_nodes)}\n"
                f"TTL: {ttl}\n"
                f"Priority: {prio_str}\n"
                f"Reply: {reply_text}\n"
                f"Processing: {elapsed_ms:.2f} ms\n"
                f"File: {saved_name}"
            ),
        )

    def count_ignored(self, reason):
        self.ignored += 1
        self.root.after(0, self.refresh_stats)
        self.root.after(0, lambda: self.log(f"[IGNORE] {reason}"))

    def close(self):
        self.stop_server()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = ServerGUI(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()
