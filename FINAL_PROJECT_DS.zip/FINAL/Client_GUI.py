import os
import time
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Set discovery peers before importing RTI DDS.
os.environ["NDDS_DISCOVERY_PEERS"] = "udpv4://10.83.246.108"

import rticonnextdds_connector as rti

CLIENT_ID_DEFAULT = "CLIENT_01"
DISCOVERY_PEERS = os.environ["NDDS_DISCOVERY_PEERS"]

PARTICIPANT = "MyParticipantLibrary::Participant"
WRITER_NAME = "MyPub::MyWriter"
READER_NAME = "MySub::MyReader"

# DDS / emergency dashboard palette
BG = "#0D1B2A"
CARD = "#1B263B"
CARD_2 = "#24344D"
ACCENT = "#415A77"
SUCCESS = "#00B4D8"
ALERT = "#EF476F"
WARNING = "#FFD166"
TEXT = "#E0E1DD"
MUTED = "#A9B4C2"
INPUT_BG = "#08111F"
WHITE = "#FFFFFF"


class ClientGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Client_GUI - R-RDSP")
        self.root.geometry("390x720")
        self.root.minsize(360, 640)
        self.root.configure(bg=BG)

        self.selected_file_path = None
        self.selected_file_name = None
        self.payload_data = None
        self.connector = None
        self.reader = None
        self.writer = None
        self.running = True
        self.has_placeholder = False

        self._configure_styles()
        self._build_ui()
        self._setup_dds()
        self._start_listener()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _configure_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "TCombobox",
            fieldbackground=INPUT_BG,
            background=INPUT_BG,
            foreground=TEXT,
            arrowcolor=TEXT,
            bordercolor=ACCENT,
            lightcolor=ACCENT,
            darkcolor=ACCENT,
            padding=5,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", INPUT_BG)],
            foreground=[("readonly", TEXT)],
            selectbackground=[("readonly", INPUT_BG)],
            selectforeground=[("readonly", TEXT)],
        )

    def _card(self, parent):
        return tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=ACCENT)

    def _label(self, parent, text, size=10, weight="normal", fg=TEXT, bg=None):
        return tk.Label(
            parent,
            text=text,
            bg=bg or CARD,
            fg=fg,
            font=("Segoe UI", size, weight),
            anchor="w",
            justify="left",
        )

    def _button(self, parent, text, command, bg=ACCENT, fg=WHITE, height=1, font=None):
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=bg,
            fg=fg,
            activebackground=SUCCESS,
            activeforeground=BG,
            relief="flat",
            bd=0,
            height=height,
            font=font or ("Segoe UI", 10, "bold"),
            cursor="hand2",
            padx=10,
            pady=6,
        )

    def _build_ui(self):
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        self.main = tk.Frame(self.root, bg=BG)
        self.main.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(5, weight=1)

        header = tk.Frame(self.main, bg=BG)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        header.grid_columnconfigure(0, weight=1)

        tk.Label(
            header,
            text="R-RDSP Client",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 18, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew")

        self.status_pill = tk.Label(
            header,
            text="CONNECTING",
            bg=WARNING,
            fg=BG,
            font=("Segoe UI", 8, "bold"),
            padx=8,
            pady=3,
        )
        self.status_pill.grid(row=0, column=1, sticky="e")

        tk.Label(
            self.main,
            text="Emergency DDS message sender",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
        ).grid(row=1, column=0, sticky="ew", pady=(0, 8))

        compose = self._card(self.main)
        compose.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        compose.grid_columnconfigure(0, weight=1)

        self._label(compose, "Message", 10, "bold").grid(
            row=0, column=0, sticky="ew", padx=12, pady=(10, 4)
        )

        self.message_box = tk.Text(
            compose,
            height=4,
            bg=INPUT_BG,
            fg=WHITE,
            insertbackground=WHITE,
            relief="flat",
            wrap="word",
            font=("Segoe UI", 10),
            padx=8,
            pady=6,
        )
        self.message_box.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 10))
        self._set_placeholder()

        controls = self._card(self.main)
        controls.grid(row=3, column=0, sticky="ew", pady=(0, 8))
        for col in range(3):
            controls.grid_columnconfigure(col, weight=1)

        self._label(controls, "TTL", 9, "bold", MUTED).grid(
            row=0, column=0, sticky="w", padx=12, pady=(10, 2)
        )
        self._label(controls, "Priority", 9, "bold", MUTED).grid(
            row=0, column=1, sticky="w", padx=6, pady=(10, 2)
        )
        self._label(controls, "Payload", 9, "bold", MUTED).grid(
            row=0, column=2, sticky="w", padx=6, pady=(10, 2)
        )

        self.ttl_var = tk.IntVar(value=4)
        self.ttl_spin = tk.Spinbox(
            controls,
            from_=1,
            to=20,
            textvariable=self.ttl_var,
            bg=INPUT_BG,
            fg=TEXT,
            buttonbackground=ACCENT,
            relief="flat",
            font=("Segoe UI", 10),
            justify="center",
            width=5,
        )
        self.ttl_spin.grid(row=1, column=0, sticky="ew", padx=(12, 6), pady=(0, 8))

        # Auto priority is the default. User can change to High or Low.
        self.priority_var = tk.StringVar(value="Auto")
        self.priority_combo = ttk.Combobox(
            controls,
            textvariable=self.priority_var,
            values=["Auto", "High", "Low"],
            state="readonly",
            width=8,
        )
        self.priority_combo.current(0)
        self.priority_combo.grid(row=1, column=1, sticky="ew", padx=6, pady=(0, 8))
        self.priority_combo.bind("<<ComboboxSelected>>", lambda _e: self._update_ttl_hint())

        self.attach_btn = self._button(controls, "Attach", self._attach_file, bg=ACCENT)
        self.attach_btn.grid(row=1, column=2, sticky="ew", padx=(6, 12), pady=(0, 8))

        self.file_label = tk.Label(
            controls,
            text="No attachment",
            bg=CARD,
            fg=MUTED,
            font=("Segoe UI", 8),
            anchor="w",
        )
        self.file_label.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 8))

        self.clear_file_btn = self._button(controls, "Clear File", self._clear_attachment, bg=CARD_2)
        self.clear_file_btn.grid(row=2, column=2, sticky="ew", padx=(6, 12), pady=(0, 8))

        self.ttl_hint = tk.Label(
            controls,
            text="Auto priority: messages containing 'help' become HIGH priority.",
            bg=CARD,
            fg=WARNING,
            font=("Segoe UI", 8),
            anchor="w",
            wraplength=340,
        )
        self.ttl_hint.grid(row=3, column=0, columnspan=3, sticky="ew", padx=12, pady=(0, 10))

        self.send_btn = self._button(
            self.main,
            "SEND MESSAGE",
            self._send_message,
            bg=ALERT,
            height=2,
            font=("Segoe UI", 11, "bold"),
        )
        self.send_btn.grid(row=4, column=0, sticky="ew", pady=(0, 8))

        lower = tk.Frame(self.main, bg=BG)
        lower.grid(row=5, column=0, sticky="nsew")
        lower.grid_columnconfigure(0, weight=1)
        lower.grid_rowconfigure(0, weight=1)
        lower.grid_rowconfigure(1, weight=1)

        replies = self._card(lower)
        replies.grid(row=0, column=0, sticky="nsew", pady=(0, 8))
        replies.grid_columnconfigure(0, weight=1)
        replies.grid_rowconfigure(1, weight=1)

        self._label(replies, "SERVER REPLIES", 11, "bold", SUCCESS).grid(
            row=0, column=0, sticky="ew", padx=12, pady=(10, 4)
        )
        self.reply_box = tk.Text(
            replies,
            height=4,
            bg=INPUT_BG,
            fg=SUCCESS,
            relief="flat",
            font=("Segoe UI", 10, "bold"),
            wrap="word",
            padx=8,
            pady=6,
        )
        self.reply_box.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 10))
        self.reply_box.insert("end", "No server reply yet.\n")
        self.reply_box.config(state="disabled")

        activity = self._card(lower)
        activity.grid(row=1, column=0, sticky="nsew")
        activity.grid_columnconfigure(0, weight=1)
        activity.grid_rowconfigure(1, weight=1)

        self._label(activity, "Activity Log", 11, "bold").grid(
            row=0, column=0, sticky="ew", padx=12, pady=(10, 4)
        )

        log_frame = tk.Frame(activity, bg=CARD)
        log_frame.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 10))
        log_frame.grid_columnconfigure(0, weight=1)
        log_frame.grid_rowconfigure(0, weight=1)

        self.log_box = tk.Text(
            log_frame,
            height=6,
            bg=INPUT_BG,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            wrap="word",
            font=("Consolas", 9),
            padx=8,
            pady=6,
        )
        self.log_box.grid(row=0, column=0, sticky="nsew")

        # Activity log is scrollable.
        self.log_scrollbar = tk.Scrollbar(
            log_frame,
            orient="vertical",
            command=self.log_box.yview,
            bg=ACCENT,
            troughcolor=CARD,
            activebackground=SUCCESS,
        )
        self.log_scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_box.configure(yscrollcommand=self.log_scrollbar.set)

    def _set_placeholder(self):
        self.placeholder = "Type your message here..."
        self.message_box.insert("1.0", self.placeholder)
        self.message_box.config(fg=MUTED)
        self.has_placeholder = True
        self.message_box.bind("<FocusIn>", self._clear_placeholder)
        self.message_box.bind("<FocusOut>", self._restore_placeholder)

    def _clear_placeholder(self, _event=None):
        if self.has_placeholder:
            self.message_box.delete("1.0", "end")
            self.message_box.config(fg=WHITE)
            self.has_placeholder = False

    def _restore_placeholder(self, _event=None):
        if not self.message_box.get("1.0", "end").strip():
            self.message_box.insert("1.0", self.placeholder)
            self.message_box.config(fg=MUTED)
            self.has_placeholder = True

    def _setup_dds(self):
        try:
            # Use url=None because RTI auto-loads USER_QOS_PROFILES.xml from the working directory.
            # Passing the XML path manually can load it twice and cause duplicate XML-object errors.
            self.connector = rti.Connector(PARTICIPANT, url=None)
            self.writer = self.connector.get_output(WRITER_NAME)
            self.reader = self.connector.get_input(READER_NAME)
            self.status_pill.config(text="CONNECTED", bg=SUCCESS, fg=BG)
            self.log(f"[OK] DDS connected | peers={DISCOVERY_PEERS}")
        except Exception as exc:
            self.status_pill.config(text="DDS ERROR", bg=ALERT, fg=WHITE)
            self.log(f"[ERROR] DDS connection failed: {exc}")
            messagebox.showerror("DDS Connection Error", str(exc))

    def _start_listener(self):
        if self.connector is None:
            return
        thread = threading.Thread(target=self._listen_loop, daemon=True)
        thread.start()

    def _listen_loop(self):
        while self.running:
            try:
                self.connector.wait(500)
                self.reader.take()
                for sample in self.reader.samples.valid_data_iter:
                    msg = sample.get_string("msg")
                    if "REPLY:" in msg:
                        ts = sample.get_string("timestamp")
                        self.root.after(0, self._show_server_reply, msg, ts)
            except rti.TimeoutError:
                continue
            except Exception as exc:
                self.root.after(0, self.log, f"[ERROR] Listener: {exc}")
                time.sleep(0.5)

    def _get_message_text(self):
        if self.has_placeholder:
            return ""
        return self.message_box.get("1.0", "end").strip()

    def _detect_priority(self, msg):
        mode = self.priority_var.get()
        if mode == "High":
            return 1
        if mode == "Low":
            return 0
        high_words = ["help", "urgent", "emergency", "danger", "fire", "sos", "medical"]
        msg_lower = msg.lower()
        return 1 if any(word in msg_lower for word in high_words) else 0

    def _validate_ttl(self, ttl, priority):
        if priority == 1:
            default_ttl, min_ttl, max_ttl = 6, 4, 20
        else:
            default_ttl, min_ttl, max_ttl = 4, 3, 10

        if ttl < min_ttl or ttl > max_ttl:
            messagebox.showwarning(
                "TTL adjusted",
                f"TTL must be between {min_ttl} and {max_ttl} for this priority. Using default {default_ttl}.",
            )
            return default_ttl
        return ttl

    def _update_ttl_hint(self):
        mode = self.priority_var.get()
        if mode == "High":
            self.ttl_hint.config(text="HIGH priority TTL range: 4-20. Default: 6.", fg=ALERT)
        elif mode == "Low":
            self.ttl_hint.config(text="LOW priority TTL range: 3-10. Default: 4.", fg=WARNING)
        else:
            self.ttl_hint.config(
                text="Auto priority: messages containing 'help','urgent','emergency','Danger' become HIGH priority.",
                fg=WARNING,
            )

    def _send_message(self):
        if self.writer is None:
            messagebox.showerror("DDS Error", "DDS is not connected.")
            return

        msg = self._get_message_text()
        has_payload = self.payload_data is not None

        if not msg and not has_payload:
            messagebox.showwarning("Empty message", "Enter a message or attach a file first.")
            return

        if has_payload and not msg:
            msg = "Image Attachment"

        priority = self._detect_priority(msg)
        ttl = self._validate_ttl(int(self.ttl_var.get()), priority)
        timestamp = str(time.time_ns())

        try:
            self.writer.instance.set_string("msg", msg)
            self.writer.instance.set_string("mac_list", CLIENT_ID_DEFAULT)
            self.writer.instance.set_number("ttl", ttl)
            self.writer.instance.set_string("timestamp", timestamp)
            self.writer.instance.set_number("priority", priority)
            self.writer.instance.set_number("battery_level", 100)
            self.writer.instance.set_number("msg_type", 1 if has_payload else 0)
            self.writer.instance.set_boolean("is_multimedia", has_payload)
            self.writer.instance.set_string("filename", self.selected_file_name or "none")

            if has_payload:
                self.writer.instance.set_dictionary({"payload": list(self.payload_data)})
            else:
                self.writer.instance.set_dictionary({"payload": []})

            self.writer.write()
            prio_text = "HIGH / Emergency" if priority == 1 else "LOW / Normal"
            self.log(f"[SENT] {prio_text} | TTL={ttl} | TS={timestamp}")

            # Clear message and attachment after sending.
            self._clear_message_after_send()
            self._clear_attachment()

        except Exception as exc:
            self.log(f"[ERROR] Send failed: {exc}")
            messagebox.showerror("Send Error", str(exc))

    def _show_server_reply(self, msg, timestamp):
        self.reply_box.config(state="normal")
        current = self.reply_box.get("1.0", "end").strip()
        if current == "No server reply yet.":
            self.reply_box.delete("1.0", "end")
        self.reply_box.insert("end", f"{time.strftime('%H:%M:%S')}  {msg}\n")
        self.reply_box.see("end")
        self.reply_box.config(state="disabled")
        self.log(f"[SERVER] {msg} | TS={timestamp}")

    def _attach_file(self):
        path = filedialog.askopenfilename(
            title="Select attachment",
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.gif *.bmp"),
                ("All files", "*.*"),
            ],
        )
        if not path:
            return

        try:
            with open(path, "rb") as file:
                data = file.read()

            if len(data) > 65536:
                messagebox.showwarning(
                    "Payload too large",
                    "DDS payload sequenceMaxLength is 65536 bytes. Choose a smaller file.",
                )
                return

            self.selected_file_path = path
            self.selected_file_name = os.path.basename(path)
            self.payload_data = data
            self.file_label.config(text=self.selected_file_name, fg=TEXT)
            self.log(f"[FILE] Attached {self.selected_file_name} ({len(data)} bytes)")

        except Exception as exc:
            messagebox.showerror("File Error", str(exc))

    def _clear_attachment(self):
        self.selected_file_path = None
        self.selected_file_name = None
        self.payload_data = None
        self.file_label.config(text="No attachment", fg=MUTED)

    def _clear_message_after_send(self):
        self.message_box.delete("1.0", "end")
        self.message_box.config(fg=MUTED)
        self.message_box.insert("1.0", self.placeholder)
        self.has_placeholder = True

    def log(self, text):
        self.log_box.insert("end", f"[{time.strftime('%H:%M:%S')}] {text}\n")
        self.log_box.see("end")

    def _on_close(self):
        self.running = False
        try:
            if self.connector is not None:
                self.connector.close()
        except Exception:
            pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = ClientGUI(root)
    root.mainloop()
