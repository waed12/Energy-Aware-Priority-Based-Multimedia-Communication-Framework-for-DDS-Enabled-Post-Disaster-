import os
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox

# Must be set before importing RTI Connector
os.environ["NDDS_DISCOVERY_PEERS"] = (
    "udpv4://10.83.246.108"
)

try:
    import psutil
except Exception:
    psutil = None

import rticonnextdds_connector as rti

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

CONFIG_NAME = "MyParticipantLibrary::Participant"
WRITER_NAME = "MyPub::MyWriter"
READER_NAME = "MySub::MyReader"

HEARTBEAT_PREFIX = "HEARTBEAT|"
HEARTBEAT_INTERVAL_SEC = 1.0
HEARTBEAT_TIMEOUT_SEC = 3.0


def create_connector():
    """
    RTI auto-loads USER_QOS_PROFILES.xml from the current directory.
    """
    return rti.Connector(CONFIG_NAME, url=None), "auto USER_QOS_PROFILES.xml"


def current_battery_percent():
    if psutil is None:
        return 100
    battery = psutil.sensors_battery()
    if battery is None:
        return 100
    return int(battery.percent)


def safe_percent(part, total):
    if total <= 0:
        return 0.0
    return (part / total) * 100.0


class RelayGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("R-RDSP Relay GUI")
        self.root.geometry("540x860")
        self.root.minsize(480, 720)

        # DDS state
        self.connector = None
        self.connector_source = "Not connected"
        self.reader = None
        self.writer = None
        self.running = False
        self.worker = None
        self.heartbeat_worker = None
        self.processed_cache = set()

        # Peer health for failover
        self.peer_last_seen = {}
        self.write_lock = threading.Lock()

        # Widget refs
        self.toggle_btn = None
        self.status_label = None
        self.connection_label = None
        self.listen_for_label = None
        self.my_id_label = None
        self.last_packet_label = None
        self.log_box = None

        # Counters
        self.forwarded = 0
        self.dropped = 0
        self.ignored = 0
        self.multimedia = 0
        self.high_priority = 0
        self.low_priority = 0
        self.ttl_expired = 0
        self.low_battery_drops = 0

        self.total_processing_ms = 0.0
        self.last_processing_ms = None
        self.total_ttl_in = 0
        self.total_ttl_out = 0
        self.started_at = None

        # Colors
        self.bg = "#0D1B2A"
        self.panel = "#1B263B"
        self.card = "#25364D"
        self.accent = "#415A77"
        self.online = "#00B4D8"
        self.alert = "#EF476F"
        self.warning = "#FFD166"
        self.text = "#E0E1DD"
        self.muted = "#A9B4C2"
        self.black = "#08111F"
        self.good = "#66E6A6"

        self.setup_styles()
        self.build_ui()
        self.on_relay_change()
        self.refresh_stats()
        self.start_ui_clock()

        self.log(f"[READY] NDDS_DISCOVERY_PEERS={os.environ['NDDS_DISCOVERY_PEERS']}")
        self.log("[READY] Relay is not connected yet. Press Start Relay.")

    # =========================
    # STYLE
    # =========================
    def setup_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background=self.bg)
        style.configure("Panel.TFrame", background=self.panel)
        style.configure("Card.TFrame", background=self.card)

        style.configure("TLabel", background=self.bg, foreground=self.text, font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background=self.panel, foreground=self.text, font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=self.bg, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("PanelMuted.TLabel", background=self.panel, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=self.bg, foreground=self.text, font=("Segoe UI", 20, "bold"))
        style.configure("Subtitle.TLabel", background=self.bg, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("PanelHeader.TLabel", background=self.panel, foreground=self.text, font=("Segoe UI", 12, "bold"))
        style.configure("StatValue.TLabel", background=self.card, foreground=self.text, font=("Segoe UI", 14, "bold"))
        style.configure("StatLabel.TLabel", background=self.card, foreground=self.muted, font=("Segoe UI", 8))
        style.configure("Good.TLabel", background=self.panel, foreground=self.good, font=("Segoe UI", 10, "bold"))
        style.configure("Bad.TLabel", background=self.panel, foreground=self.alert, font=("Segoe UI", 10, "bold"))

        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=(8, 8))
        style.configure("Start.TButton", background=self.online, foreground=self.black)
        style.map("Start.TButton", background=[("active", "#27C7E6")])
        style.configure("Stop.TButton", background=self.alert, foreground="white")
        style.map("Stop.TButton", background=[("active", "#D93E63")])
        style.configure("Secondary.TButton", background=self.accent, foreground=self.text)
        style.map("Secondary.TButton", background=[("active", "#526C8B")])

        style.configure(
            "TSpinbox",
            fieldbackground=self.black,
            background=self.card,
            foreground=self.text,
            arrowcolor=self.text,
            bordercolor=self.accent,
            lightcolor=self.accent,
            darkcolor=self.accent,
        )

        style.configure(
            "TCheckbutton",
            background=self.panel,
            foreground=self.text,
            font=("Segoe UI", 9),
        )

    # =========================
    # UI
    # =========================
    def build_ui(self):
        self.root.configure(bg=self.bg)

        self.main = ttk.Frame(self.root, padding=14)
        self.main.pack(fill="both", expand=True)
        self.main.columnconfigure(0, weight=1)
        self.main.rowconfigure(2, weight=1)

        ttk.Label(self.main, text="R-RDSP Relay Node", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            self.main,
            text="Automatic failover relay with heartbeat-based live-node detection.",
            style="Subtitle.TLabel",
            wraplength=480,
        ).grid(row=1, column=0, sticky="ew", pady=(4, 10))

        self.content = ttk.Frame(self.main)
        self.content.grid(row=2, column=0, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=0)
        self.content.rowconfigure(1, weight=0)
        self.content.rowconfigure(2, weight=1)

        self.settings_frame = ttk.Frame(self.content, style="Panel.TFrame", padding=12)
        self.settings_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        self.stats_frame = ttk.Frame(self.content)
        self.stats_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))

        self.activity_frame = ttk.Frame(self.content, style="Panel.TFrame", padding=12)
        self.activity_frame.grid(row=2, column=0, sticky="nsew")
        self.activity_frame.columnconfigure(0, weight=1)
        self.activity_frame.rowconfigure(1, weight=1)

        self.build_settings()
        self.build_stats()
        self.build_activity()

        self.root.bind("<Configure>", self.on_resize)

    def build_settings(self):
        self.settings_frame.columnconfigure(0, weight=1)
        self.settings_frame.columnconfigure(1, weight=1)

        ttk.Label(self.settings_frame, text="Relay Settings", style="PanelHeader.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )

        ttk.Label(self.settings_frame, text="Relay Number", style="PanelMuted.TLabel").grid(row=1, column=0, sticky="w")
        ttk.Label(self.settings_frame, text="Total Relays", style="PanelMuted.TLabel").grid(row=1, column=1, sticky="w", padx=(10, 0))

        self.relay_num_var = tk.IntVar(value=1)
        self.total_relays_var = tk.IntVar(value=1)
        self.battery_var = tk.IntVar(value=current_battery_percent())

        self.relay_spin = ttk.Spinbox(
            self.settings_frame,
            from_=1,
            to=99,
            textvariable=self.relay_num_var,
            command=self.on_relay_change,
            width=8,
        )
        self.relay_spin.grid(row=2, column=0, sticky="ew", pady=(4, 10))

        self.total_spin = ttk.Spinbox(
            self.settings_frame,
            from_=1,
            to=99,
            textvariable=self.total_relays_var,
            command=self.on_relay_change,
            width=8,
        )
        self.total_spin.grid(row=2, column=1, sticky="ew", padx=(10, 0), pady=(4, 10))

        ttk.Label(self.settings_frame, text="MY ID", style="PanelMuted.TLabel").grid(row=3, column=0, sticky="w")
        ttk.Label(self.settings_frame, text="LISTENING FOR", style="PanelMuted.TLabel").grid(row=3, column=1, sticky="w", padx=(10, 0))

        self.my_id_label = ttk.Label(self.settings_frame, text="RELAY_01", style="PanelHeader.TLabel")
        self.my_id_label.grid(row=4, column=0, sticky="w", pady=(2, 8))

        self.listen_for_label = ttk.Label(self.settings_frame, text="CLIENT_01", style="PanelHeader.TLabel")
        self.listen_for_label.grid(row=4, column=1, sticky="w", padx=(10, 0), pady=(2, 8))

        self.drop_low_var = tk.BooleanVar(value=True)
        self.show_ignored_var = tk.BooleanVar(value=True)

        ttk.Checkbutton(
            self.settings_frame,
            text="Drop LOW priority if battery < 25%",
            variable=self.drop_low_var,
        ).grid(row=5, column=0, columnspan=2, sticky="w", pady=(4, 2))

        ttk.Checkbutton(
            self.settings_frame,
            text="Show ignored packets",
            variable=self.show_ignored_var,
        ).grid(row=6, column=0, columnspan=2, sticky="w", pady=(0, 8))

        self.status_label = ttk.Label(self.settings_frame, text="Disconnected", style="Bad.TLabel")
        self.status_label.grid(row=7, column=0, sticky="w", pady=(2, 8))

        self.connection_label = ttk.Label(self.settings_frame, text="DDS: Not connected", style="PanelMuted.TLabel")
        self.connection_label.grid(row=7, column=1, sticky="e", pady=(2, 8))

        self.toggle_btn = ttk.Button(
            self.settings_frame,
            text="Start Relay",
            style="Start.TButton",
            command=self.toggle_relay,
        )
        self.toggle_btn.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(0, 8))

        tools_row = ttk.Frame(self.settings_frame, style="Panel.TFrame")
        tools_row.grid(row=9, column=0, columnspan=2, sticky="ew")
        tools_row.columnconfigure(0, weight=1)
        tools_row.columnconfigure(1, weight=1)
        tools_row.columnconfigure(2, weight=1)

        ttk.Button(tools_row, text="Apply ID", style="Secondary.TButton", command=self.on_relay_change).grid(
            row=0, column=0, sticky="ew", padx=(0, 4)
        )
        ttk.Button(tools_row, text="Battery", style="Secondary.TButton", command=self.use_current_battery).grid(
            row=0, column=1, sticky="ew", padx=4
        )
        ttk.Button(tools_row, text="Clear Log", style="Secondary.TButton", command=self.clear_log).grid(
            row=0, column=2, sticky="ew", padx=(4, 0)
        )

    def build_stats(self):
        self.stats_container = self.stats_frame
        self.stats_widgets = []

        stat_specs = [
            ("Forwarded", "0"),
            ("Dropped", "0"),
            ("Ignored", "0"),
            ("Multimedia", "0"),
            ("Avg Time", "0.00 ms"),
            ("Last Time", "0.00 ms"),
            ("Packet Rate", "0.00/s"),
            ("Drop %", "0.0%"),
            ("Avg TTL In", "0.0"),
            ("Avg TTL Out", "0.0"),
            ("High", "0"),
            ("Low", "0"),
        ]

        for label, value in stat_specs:
            self.stats_widgets.append(self.create_stat_card(self.stats_container, label, value))

        (
            self.forwarded_value,
            self.dropped_value,
            self.ignored_value,
            self.multimedia_value,
            self.avg_time_value,
            self.last_time_value,
            self.packet_rate_value,
            self.drop_percent_value,
            self.avg_ttl_in_value,
            self.avg_ttl_out_value,
            self.high_value,
            self.low_value,
        ) = [item[1] for item in self.stats_widgets]

        self.layout_stats_cards()

    def create_stat_card(self, parent, label, value):
        frame = ttk.Frame(parent, style="Card.TFrame", padding=(10, 8))
        title = ttk.Label(frame, text=label, style="StatLabel.TLabel")
        val = ttk.Label(frame, text=value, style="StatValue.TLabel")
        title.pack(anchor="w")
        val.pack(anchor="w")
        return frame, val

    def layout_stats_cards(self):
        width = max(self.root.winfo_width(), 390)

        if width < 620:
            cols = 2
        elif width < 980:
            cols = 3
        else:
            cols = 4

        for child in self.stats_container.winfo_children():
            child.grid_forget()

        for c in range(cols):
            self.stats_container.columnconfigure(c, weight=1)

        for index, (frame, _) in enumerate(self.stats_widgets):
            row = index // cols
            col = index % cols
            frame.grid(row=row, column=col, sticky="ew", padx=4, pady=4)

    def build_activity(self):
        ttk.Label(self.activity_frame, text="Activity Log", style="PanelHeader.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 8)
        )

        log_holder = ttk.Frame(self.activity_frame, style="Panel.TFrame")
        log_holder.grid(row=1, column=0, sticky="nsew")
        log_holder.columnconfigure(0, weight=1)
        log_holder.rowconfigure(0, weight=1)

        self.log_box = tk.Text(
            log_holder,
            bg=self.black,
            fg=self.text,
            insertbackground=self.text,
            relief="flat",
            font=("Consolas", 9),
            wrap="word",
            height=8,
        )
        self.log_box.grid(row=0, column=0, sticky="nsew")

        self.log_scroll = ttk.Scrollbar(log_holder, orient="vertical", command=self.log_box.yview)
        self.log_scroll.grid(row=0, column=1, sticky="ns")
        self.log_box.configure(yscrollcommand=self.log_scroll.set)

        self.log_box.bind("<MouseWheel>", self.scroll_log)
        self.log_box.bind("<Button-4>", self.scroll_log)
        self.log_box.bind("<Button-5>", self.scroll_log)

        ttk.Label(self.activity_frame, text="Last Packet", style="PanelHeader.TLabel").grid(
            row=2, column=0, sticky="w", pady=(10, 4)
        )

        self.last_packet_label = ttk.Label(
            self.activity_frame,
            text="No packet processed yet",
            style="PanelMuted.TLabel",
            justify="left",
            wraplength=480,
        )
        self.last_packet_label.grid(row=3, column=0, sticky="ew")

    def scroll_log(self, event):
        if getattr(event, "num", None) == 4:
            self.log_box.yview_scroll(-1, "units")
        elif getattr(event, "num", None) == 5:
            self.log_box.yview_scroll(1, "units")
        else:
            direction = -1 if event.delta > 0 else 1
            self.log_box.yview_scroll(direction, "units")
        return "break"

    def on_resize(self, event=None):
        width = self.root.winfo_width()

        if width >= 980:
            self.content.columnconfigure(0, weight=1)
            self.content.columnconfigure(1, weight=2)

            self.settings_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))
            self.stats_frame.grid(row=0, column=1, sticky="nsew", pady=(0, 10))
            self.activity_frame.grid(row=1, column=0, columnspan=2, sticky="nsew")
            self.last_packet_label.configure(wraplength=max(400, width - 80))
        else:
            self.content.columnconfigure(0, weight=1)
            self.content.columnconfigure(1, weight=0)

            self.settings_frame.grid(row=0, column=0, sticky="ew", padx=0, pady=(0, 10))
            self.stats_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))
            self.activity_frame.grid(row=2, column=0, sticky="nsew")
            self.last_packet_label.configure(wraplength=max(360, width - 50))

        self.layout_stats_cards()

    # =========================
    # RELAY ID / TOPOLOGY
    # =========================
    def my_id(self):
        return f"RELAY_{int(self.relay_num_var.get()):02d}"

    def listen_for(self):
        n = int(self.relay_num_var.get())
        return "CLIENT_01" if n == 1 else f"RELAY_{n - 1:02d}"

    def update_downstream(self):
        """
        Automatic failover:
        For relay N, try downstream relays N+1..total_relays in order.
        If I'm the final relay, my next hop is SERVER.
        """
        my_num = int(self.relay_num_var.get())
        total = int(self.total_relays_var.get())

        if my_num >= total:
            return ["SERVER"]

        return [f"RELAY_{i:02d}" for i in range(my_num + 1, total + 1)]

    def on_relay_change(self):
        if self.my_id_label is not None:
            self.my_id_label.configure(text=self.my_id())
        if self.listen_for_label is not None:
            self.listen_for_label.configure(text=self.listen_for())

        if self.running:
            self.log(f"[INFO] Relay changed | MY_ID={self.my_id()} | LISTEN_FOR={self.listen_for()}")

    # =========================
    # HELPERS
    # =========================
    def use_current_battery(self):
        self.battery_var.set(current_battery_percent())
        self.log(f"[OK] Battery updated to {self.battery_var.get()}%")

    def log(self, text):
        if self.log_box is None:
            return
        self.log_box.insert("end", f"{time.strftime('%H:%M:%S')}  {text}\n")
        self.log_box.see("end")

    def clear_log(self):
        if self.log_box is not None:
            self.log_box.delete("1.0", "end")

    def set_last_packet(self, text):
        if self.last_packet_label is not None:
            self.last_packet_label.configure(text=text)

    # =========================
    # STATS
    # =========================
    def total_seen(self):
        return self.forwarded + self.dropped + self.ignored

    def handled_seen(self):
        return self.forwarded + self.dropped

    def average_processing_ms(self):
        count = self.handled_seen()
        if count <= 0:
            return 0.0
        return self.total_processing_ms / count

    def average_ttl_in(self):
        if self.forwarded <= 0:
            return 0.0
        return self.total_ttl_in / self.forwarded

    def average_ttl_out(self):
        if self.forwarded <= 0:
            return 0.0
        return self.total_ttl_out / self.forwarded

    def packet_rate(self):
        if not self.started_at:
            return 0.0
        elapsed = time.perf_counter() - self.started_at
        if elapsed <= 0:
            return 0.0
        return self.total_seen() / elapsed

    def refresh_stats(self):
        if self.forwarded_value is None:
            return

        self.forwarded_value.configure(text=str(self.forwarded))
        self.dropped_value.configure(text=str(self.dropped))
        self.ignored_value.configure(text=str(self.ignored))
        self.multimedia_value.configure(text=str(self.multimedia))
        self.avg_time_value.configure(text=f"{self.average_processing_ms():.2f} ms")
        self.last_time_value.configure(
            text="0.00 ms" if self.last_processing_ms is None else f"{self.last_processing_ms:.2f} ms"
        )
        self.packet_rate_value.configure(text=f"{self.packet_rate():.2f}/s")
        self.drop_percent_value.configure(text=f"{safe_percent(self.dropped, self.handled_seen()):.1f}%")
        self.avg_ttl_in_value.configure(text=f"{self.average_ttl_in():.1f}")
        self.avg_ttl_out_value.configure(text=f"{self.average_ttl_out():.1f}")
        self.high_value.configure(text=str(self.high_priority))
        self.low_value.configure(text=str(self.low_priority))

    def record_processing_time(self, elapsed_ms):
        self.last_processing_ms = elapsed_ms
        self.total_processing_ms += elapsed_ms

    def start_ui_clock(self):
        self.refresh_stats()
        self.root.after(1000, self.start_ui_clock)

    # =========================
    # START / STOP
    # =========================
    def toggle_relay(self):
        if self.running:
            self.stop_relay()
        else:
            self.start_relay()

    def update_toggle_button(self):
        if self.toggle_btn is None:
            return
        if self.running:
            self.toggle_btn.configure(text="Stop Relay", style="Stop.TButton")
        else:
            self.toggle_btn.configure(text="Start Relay", style="Start.TButton")

    def start_relay(self):
        if self.running:
            return

        self.on_relay_change()
        self.processed_cache.clear()
        self.peer_last_seen.clear()

        try:
            self.connector, self.connector_source = create_connector()
            self.reader = self.connector.get_input(READER_NAME)
            self.writer = self.connector.get_output(WRITER_NAME)
        except Exception as exc:
            if self.status_label is not None:
                self.status_label.configure(text="Connection failed", style="Bad.TLabel")
            if self.connection_label is not None:
                self.connection_label.configure(text="DDS: Failed")
            self.log(f"[ERROR] DDS connection failed: {exc}")
            messagebox.showerror("DDS Connection Error", str(exc))
            return

        self.running = True
        self.started_at = time.perf_counter()
        self.update_toggle_button()

        if self.status_label is not None:
            self.status_label.configure(text=f"Connected as {self.my_id()}", style="Good.TLabel")
        if self.connection_label is not None:
            self.connection_label.configure(text="DDS: Connected")

        self.log(f"[CONNECTED] DDS connected using {self.connector_source}")
        self.log(
            f"[START] Relay Online | MY_ID={self.my_id()} | LISTEN_FOR={self.listen_for()} | "
            f"Battery={self.battery_var.get()}%"
        )

        self.worker = threading.Thread(target=self.relay_loop, daemon=True)
        self.worker.start()

        self.heartbeat_worker = threading.Thread(target=self.heartbeat_loop, daemon=True)
        self.heartbeat_worker.start()

    def stop_relay(self):
        self.running = False
        self.update_toggle_button()

        try:
            if self.connector is not None:
                self.connector.close()
        except Exception:
            pass

        self.connector = None
        self.reader = None
        self.writer = None

        if self.status_label is not None:
            self.status_label.configure(text="Disconnected", style="Bad.TLabel")
        if self.connection_label is not None:
            self.connection_label.configure(text="DDS: Not connected")

        self.log("[DISCONNECTED] Relay stopped")

    # =========================
    # HEARTBEATS
    # =========================
    def heartbeat_loop(self):
        while self.running:
            try:
                self.publish_heartbeat()
            except Exception as exc:
                if self.running:
                    self.root.after(0, lambda e=exc: self.log(f"[ERROR] Heartbeat failed: {e}"))
            time.sleep(HEARTBEAT_INTERVAL_SEC)

    def publish_heartbeat(self):
        if self.writer is None:
            return

        ts = str(time.time_ns())
        with self.write_lock:
            self.writer.instance.set_string("msg", f"{HEARTBEAT_PREFIX}{self.my_id()}")
            self.writer.instance.set_string("mac_list", self.my_id())
            self.writer.instance.set_number("ttl", 1)
            self.writer.instance.set_string("timestamp", ts)
            self.writer.instance.set_number("priority", 0)
            self.writer.instance.set_number("battery_level", int(self.battery_var.get()))
            self.writer.instance.set_number("msg_type", 0)
            self.writer.instance.set_boolean("is_multimedia", False)
            self.writer.instance.set_string("filename", "none")
            self.writer.instance.set_dictionary({"payload": []})
            self.writer.write()

    def mark_seen(self, node_id):
        if node_id and node_id.startswith("RELAY_"):
            self.peer_last_seen[node_id] = time.monotonic()

    def peer_alive(self, node_id):
        if node_id == "SERVER":
            return True
        last_seen = self.peer_last_seen.get(node_id)
        if last_seen is None:
            return False
        return (time.monotonic() - last_seen) <= HEARTBEAT_TIMEOUT_SEC

    # =========================
    # ROUTING
    # =========================
    def choose_next_hop(self):
        """
        Automatic failover across downstream relays.
        If I am the final relay, next hop is SERVER.
        """
        downstream = self.update_downstream()
        if downstream == ["SERVER"]:
            return "SERVER"

        for hop in downstream:
            if self.peer_alive(hop):
                return hop

        return None

    # =========================
    # DDS LOOP
    # =========================
    def relay_loop(self):
        while self.running:
            try:
                self.connector.wait(500)
            except rti.TimeoutError:
                continue
            except Exception as exc:
                if self.running:
                    self.root.after(0, lambda e=exc: self.log(f"[ERROR] Wait failed: {e}"))
                continue

            try:
                self.reader.take()
                for sample in self.reader.samples.valid_data_iter:
                    self.process_sample(sample)
            except Exception as exc:
                self.root.after(0, lambda e=exc: self.log(f"[ERROR] Sample handling failed: {e}"))

    # =========================
    # PACKET PROCESSING
    # =========================
    def process_sample(self, sample):
        start = time.perf_counter()

        msg = sample.get_string("msg")
        if msg.startswith(HEARTBEAT_PREFIX):
            sender = msg.split("|", 1)[1].strip() if "|" in msg else ""
            self.mark_seen(sender)
            return

        ts = sample.get_string("timestamp")
        raw_path = sample.get_string("mac_list") or ""
        path_part = raw_path
        target_text = ""

        if "|NEXT=" in raw_path:
            path_part, target_text = raw_path.split("|NEXT=", 1)
            target_text = target_text.strip().upper()

        self.log(f"[RX] msg={msg} path={raw_path}")

        path_nodes = [node.strip() for node in path_part.split(",") if node.strip()]
        sender = path_nodes[-1] if path_nodes else ""
        my_id = self.my_id()

        if my_id in path_nodes:
            self.count_ignored(f"Already seen by {my_id} | path={path_part}")
            return

        if ts in self.processed_cache:
            self.count_ignored(f"Duplicate timestamp {ts}")
            return

        priority = int(sample.get_number("priority"))
        prio_str = "HIGH / Emergency" if priority == 1 else "LOW / Normal"

        # If this packet is explicitly targeted to a relay, only that relay handles it.
        if target_text:
            if target_text != my_id:
                self.count_ignored(
                    f"Packet targeted for {target_text}, not {my_id} | priority={prio_str} | msg='{msg}'"
                )
                return
        else:
            if sender != self.listen_for():
                self.count_ignored(
                    f"Not my turn | expected={self.listen_for()} | got={sender} | msg='{msg}'"
                )
                return

        battery = int(self.battery_var.get())

        if self.drop_low_var.get() and battery < 25 and priority == 0:
            self.processed_cache.add(ts)
            self.dropped += 1
            self.low_battery_drops += 1

            elapsed_ms = (time.perf_counter() - start) * 1000.0
            self.record_processing_time(elapsed_ms)

            self.root.after(0, self.refresh_stats)
            self.root.after(
                0,
                lambda: self.log(
                    f"[DROP] '{msg}' | reason=Low battery {battery}% and {prio_str} | time={elapsed_ms:.2f}ms"
                ),
            )
            self.root.after(
                0,
                lambda: self.set_last_packet(
                    f"DROPPED\nMessage: {msg}\nReason: Low battery {battery}%\nPriority: {prio_str}\nProcessing: {elapsed_ms:.2f} ms"
                ),
            )
            return

        ttl = int(sample.get_number("ttl"))
        if ttl <= 0:
            self.ttl_expired += 1
            self.dropped += 1
            self.processed_cache.add(ts)

            elapsed_ms = (time.perf_counter() - start) * 1000.0
            self.record_processing_time(elapsed_ms)

            self.root.after(0, self.refresh_stats)
            self.root.after(0, lambda: self.log(f"[DROP] '{msg}' | reason=TTL expired | time={elapsed_ms:.2f}ms"))
            return

        next_hop = self.choose_next_hop()
        if next_hop is None:
            self.dropped += 1
            self.processed_cache.add(ts)

            elapsed_ms = (time.perf_counter() - start) * 1000.0
            self.record_processing_time(elapsed_ms)

            self.root.after(0, self.refresh_stats)
            self.root.after(
                0,
                lambda: self.log(f"[DROP] '{msg}' | no alive downstream relay available"),
            )
            return

        new_ttl = ttl - 1
        self.processed_cache.add(ts)

        data = sample.get_dictionary()

        if next_hop == "SERVER":
            data["mac_list"] = f"{path_part},{my_id}"
        else:
            data["mac_list"] = f"{path_part},{my_id}|NEXT={next_hop}"

        data["ttl"] = new_ttl

        if sample.get_boolean("is_multimedia"):
            file_size = len(sample.get_dictionary().get("payload", []))
            self.multimedia += 1
            media_note = f" | multimedia={file_size} bytes"
        else:
            media_note = ""

        with self.write_lock:
            self.writer.instance.set_dictionary(data)
            self.writer.write()

        elapsed_ms = (time.perf_counter() - start) * 1000.0
        self.record_processing_time(elapsed_ms)

        self.forwarded += 1
        self.total_ttl_in += ttl
        self.total_ttl_out += new_ttl

        self.root.after(0, self.refresh_stats)
        self.root.after(
            0,
            lambda: self.log(
                f"[FORWARD] '{msg}' | from={sender} to={my_id} | next={next_hop} | "
                f"TTL {ttl}->{new_ttl} | battery={battery}% | priority={prio_str} | "
                f"time={elapsed_ms:.2f}ms{media_note}"
            ),
        )
        self.root.after(
            0,
            lambda: self.set_last_packet(
                f"FORWARDED\nMessage: {msg}\nPath: {path_part} -> {my_id}\nNext hop: {next_hop}\nTTL: {ttl} -> {new_ttl}\nPriority: {prio_str}\nBattery: {battery}%\nProcessing: {elapsed_ms:.2f} ms"
            ),
        )

    def count_ignored(self, reason):
        self.ignored += 1
        self.root.after(0, self.refresh_stats)
        if self.show_ignored_var.get():
            self.root.after(0, lambda: self.log(f"[IGNORE] {reason}"))

    def close(self):
        self.running = False
        try:
            if self.connector is not None:
                self.connector.close()
        except Exception:
            pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = RelayGUI(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()